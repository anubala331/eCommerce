<?php

        include 'dbconnect.php';

        $method = $_SERVER['REQUEST_METHOD'];

        if($method == "GET"){
            // if the GET Paramater 'id' is specified in the request, only get the specified user id.
            if(isset($_GET['id'])){
                $sql = $db->prepare('SELECT * FROM user WHERE id = :id');
	            $sql->bindValue(':id', $_GET['id']);
	            $sql->execute();
	            if($user = $sql->fetchAll(PDO::FETCH_ASSOC)){
                    $response = $user;
                }
	            else
                    $response = array("message"=>"User Id ". $_GET['id']." not found");
                
                print json_encode($response);

            }


            // otherwise, get all users from the database.
            else {
                $sql = $db->prepare('SELECT * FROM user');
	            $sql->execute();
                if($user = $sql->fetchAll(PDO::FETCH_ASSOC)){
                    $response = $user;
                }
	            else
                    $response = array("message"=>"No Entry Found in Database");
                
                print json_encode($response);

            }
        }

        else if( $method == "POST"){
            
            // Get the json from post body of the request
   
            $post= trim(file_get_contents("php://input"));
            $json= json_decode($post, true);
            // Create Prepared Statement for adding a new User record in the database.
            $cmd= 'INSERT INTO user(firstname, lastname, username, email, shipping_address, password) '.'VALUES(:firstname, :lastname, :username, :email, :shipping_address, :password)';
            $sql= $db->prepare($cmd);

            // Bind the values of the post body stored in the variable $json with the database columns.
            $sql->bindValue(':firstname', $json['firstname']);
            $sql->bindValue(':lastname', $json['lastname']);
            $sql->bindValue(':username', $json['username']);
            $sql->bindValue(':email', $json['email']);
            $sql->bindValue(':shipping_address', $json['shipping_address']);
            $hash_pass= password_hash($json['password'], PASSWORD_DEFAULT);
            $sql->bindValue(':password', $hash_pass);

            
            

            // Execute the query.
            $sql->execute();

            //  Send a response back to the client to inform about successful addition and the id of the created record.
            $response= array("message"=>"New User with id ". $db->lastInsertId() . " added");
            print json_encode($response);

        }
        else if ($method == "PUT") {
            // Get the http body from the request
            $post = trim(file_get_contents("php://input"));
            $json = json_decode($post, true);

            // construct the prepared statement based on the id provided
            if(isset($_GET['id'])){
                    $fieldlist = "";
                    if($json['firstname']) $fieldlist .= "firstname=:firstname,";
                    if($json['lastname']) $fieldlist .= "lastname=:lastname,";
                    if($json['username']) $fieldlist .= "username=:username,";
                    if($json['email']) $fieldlist .= "email=:email,";
                    if($json['shipping_address']) $fieldlist .= "shipping_address=:shipping_address,";
                    if($json['password']) $fieldlist .= "password=:password";
                    
                                
                    // trim any trailing ','s
                    $fieldlist = trim($fieldlist, ",");
                    
                    // create update statement
                    $cmd = "UPDATE user SET $fieldlist WHERE id = :id";
                    $sql = $db->prepare($cmd);
                    
                    // bind values
                    if($json['firstname']) $sql->bindValue(':firstname', $json['firstname']);
                    if($json['lastname']) $sql->bindValue(':lastname', $json['lastname']);
                    if($json['username']) $sql->bindValue(':username', $json['username']);
                    if($json['email']) $sql->bindValue(':email', $json['email']);
                  
                    if($json['shipping_address']) $sql->bindValue(':shipping_address', $json['shipping_address']);
                    $hash_pass= password_hash($json['password'], PASSWORD_DEFAULT);
                    if($json['password']) $sql->bindValue(':password', $hash_pass);
                    $sql->bindValue(':id', $_GET['id']);

                    // execute statement
                    
                    $sql->execute();
                        if($sql->rowCount()){
                            $response = array("message" => "User Record Updated");
                        }
                        else
                            $response = array("message"=>"User Id ". $_GET['id']." not found");
    
                    // Send a response back to the client to inform about successfuly  modified records.
                    print json_encode($response);
            }
            else{
                // Send a response back to the client to inform about empty ID.
                $response = array("message" => "ID is empty");
                print json_encode($response);
            }
            
            
        }

        else if ($method == "DELETE"){
            if(isset($_GET['id'])){
                
                if(isset($_GET['id'])){
                    //first check the id in the database
                    $sql = $db->prepare('SELECT * FROM user WHERE id = :id');
                    $sql->bindValue(':id', $_GET['id']);
                    $sql->execute();
                    if($sql->rowCount()){
                        //Delete after checking
                        $sql = $db->prepare('DELETE FROM user WHERE id = :id');
                        $sql->bindValue(':id', $_GET['id']);
                        $sql->execute();
                        $response = array("message" => "User Record Deleted");
                    }
                    else
                        $response = array("message"=>"User Id ". $_GET['id']." not found");
                        // Send a response back to the client to inform about successfuly  modified records.
                     print json_encode($response);
             }
             else{
                 // Send a response back to the client to inform about empty ID.
                $response = array("message" => "ID is empty");
                print json_encode($response);
            }
        }
    }
?>