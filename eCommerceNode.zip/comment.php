<?php

    // This is the Product resource file. We will be defining RESTFul methods that will allow you to 
    // perform basic CRUD methods. 

    // STEP 1. include the database connection file.
        include("dbconnect.php");

        $method = $_SERVER['REQUEST_METHOD'];

        if($method == "GET"){
            // if the GET Paramater 'id' is specified in the request, only get the specified user id.
            if(isset($_GET['userid'])) {
                $sql = $db->prepare('SELECT * FROM purchase_history JOIN comment WHERE userid = :userid');
	            $sql->bindValue(':userid', $_GET['userid']);
	            $sql->execute();
	
	            if($user = $sql->fetch(PDO::FETCH_ASSOC)){
                    $response = json_encode($user);
                }
	            else
                    $response = array("message"=>"Comment not found");
                
                print $response;

            }

            // otherwise, get all users from the database.
            else {
                $sql = $db->prepare('SELECT * FROM comment');
	            $sql->execute();
                $users = $sql->fetchAll(PDO::FETCH_ASSOC);
                print (json_encode($users));

            }
        }

        else if( $method == "POST"){
            
            // Get the http body from the request
            $post = trim(file_get_contents("php://input"));
            $json = json_decode($post, true);

            // save comments
            $sql = 'INSERT INTO comment(userid,productid,rating,image,comment)values(:userid,:productid,:rating,:image,:comment)';

            $data = [
            'userid' => $json['userid'],
            'productid'  => $json['productid'],
            'rating'  => $json['rating'],
            'image'      => $json['image'],
            'comment'      => $json['comment'],
            ];
    
            $stmt = $db->prepare($sql);
            $stmt->execute($data);
            // Send a response back to the client to inform about successfuly  modified records.
            $response = array("message" => "Product comment saved");
            print json_encode($response);

        } else if( $method == "PUT"){
            
            // Get the http body from the request
            $post = trim(file_get_contents("php://input"));
            $json = json_decode($post, true);

            // save comments
            $sql = 'UPDATE  comment SET rating =:rating,image = :image,comment = :comment WHERE userid =:userid and productid = :productid';

            $data = [
            'userid' => $json['userid'],
            'productid'  => $json['productid'],
            'rating'  => $json['rating'],
            'image'      => $json['image'],
            'comment'      => $json['comment'],
            ];
    
            $stmt = $db->prepare($sql);
            $stmt->execute($data);
            // Send a response back to the client to inform about successfuly  modified records.
            $response = array("message" => "Product comment updated");
            print json_encode($response);

        } else if ($method == "DELETE") {
            // CHALLENGE: Delete the user 
            // if the GET Paramater 'id' is specified in the request, only get the specified product id.
            if(isset($_GET['id'])) {   
            // create update statement
            $sql = $db->prepare('DELETE FROM comment WHERE userid = :userid and productid = :productid');
	        $sql->bindValue(':userid', $_GET['userid']);
            $sql->bindValue(':productid', $_GET['productid']);
	        $sql->execute();
	
	       // Send a response back to the client to inform about successfuly deleted records.
            $response = array("message" => "Comment Deleted Successfully");
            print json_encode($response);
            }  else {
                $response = array("message" => "DELETION: Comment not found");
            }
        } else {
            $response = array("message" => "Wrong Method");
            print json_encode($response);
        }
         
