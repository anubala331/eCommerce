<?php
        include 'dbconnect.php';

        $method = $_SERVER['REQUEST_METHOD'];
        function add_multiple_products($json, $cartid, $db)
        {
            for($i=1; $i <= $json['quantity']; $i++) 
            {
            $query = "INSERT INTO cart_products(cartid, productid) VALUES(:cartid, :productid)";
            
            $sql = $db->prepare($query);
            
            // STEP 5: Bind the values of the post body stored in the variable $json with the database columns.
            $sql->bindValue(':cartid', $cartid);
            
            $sql->bindValue(':productid', $json['product' . $i]);


            // STEP 6: Execute the query.
            $sql->execute();
            }
        }

        function delete_multiple_products($json, $cartid, $db)
        {
                $sql = $db->prepare('DELETE FROM cart_products WHERE cartid = :cartid');
                $sql->bindValue(':cartid', $cartid);
                $sql->execute();
        }


        function update_quantity_put($userid, $quantity, $db)
        {
            $fieldlist = "";

            if(isset($quantity) && isset($userid)) { 
                $fieldlist .= "quantity=:quantity";

             $query = "UPDATE cart SET $fieldlist WHERE userid = :userid";
             
             $sql = $db->prepare($query);
             
             // STEP 5: Bind the values of the post body stored in the variable $json with the database columns.
             $sql->bindValue(':userid', $userid);
             
             $sql->bindValue(':quantity', $quantity);
 
             // STEP 6: Execute the query.
             $db->beginTransaction();
             $sql->execute();
             $db->commit();
            }
             
        }

        
        function delete_usercart_product($userid, $cartid, $productid, $db)
        {

            if(isset($userid) && isset($productid)) {   
        
                $sql = $db->prepare('DELETE FROM cart_products WHERE cartid = :cartid and productid = :productid');
                $sql->bindValue(':cartid', $cartid);
                $sql->bindValue(':productid', $productid);
                $sql->execute();

               // Send a response back to the client to inform about successfuly deleted records.
                $response = array("message" => "User Product From Cart is Deleted Successfully");
                }  else {
                    $response = array("message" => "DELETION: User Product not found in Cart");
                }
                print json_encode($response);

                update_quantity_delete($userid, $db);

        }

        function update_quantity_delete($userid, $db)
        {
             $query = "UPDATE cart SET quantity = quantity - 1 WHERE userid = :userid";
             
             $sql = $db->prepare($query);
             
             // STEP 5: Bind the values of the post body stored in the variable $json with the database columns.
             $sql->bindValue(':userid', $userid);
 
             // STEP 6: Execute the query.
             $db->beginTransaction();
             $sql->execute();
             $db->commit();
        }


        if($method == "GET") {
            // if the GET Paramater 'id' is specified in the request, only get the specified cart id.
            if(isset($_GET['userid'])) {
                $sql = $db->prepare('SELECT id, quantity FROM cart WHERE userid = :userid');
	            $sql->bindValue(':userid', $_GET['userid']);
	            $sql->execute();

	        if($cart = $sql->fetch(PDO::FETCH_ASSOC)) {
                    $response = json_encode($cart);

                    $sql = $db->prepare('SELECT productname FROM cart_products INNER JOIN product WHERE cartid = :cartid');
                    $sql->bindValue(':cartid', $cart['id']);
                    $sql->execute();
                    if($cartproducts = $sql->fetch(PDO::FETCH_ASSOC)) {
                        $response .= json_encode($cartproducts);
                    }
            }
	        else {
                $response = json_encode(array("message"=>"GET: Cart not found"));
            }
                
            print $response;

            } else {
                $error = "Error: User not found";
                print $error;
            }
        } else if( $method == "POST") {
            // STEP 3: Get the json from post body of the request
            $post = trim(file_get_contents("php://input"));
            $json = json_decode($post, true);
           

            // Step 4: Create Prepared Statement for adding a new cart record in the database.
            $query = "INSERT INTO cart(userid, quantity) VALUES(:userid, :quantity)";
            
            $sql = $db->prepare($query);
            
            // STEP 5: Bind the values of the post body stored in the variable $json with the database columns.
            $sql->bindValue(':userid', $json['userid']);
            
            $sql->bindValue(':quantity', $json['quantity']);

            // STEP 6: Execute the query.
            $sql->execute();
            
            // STEP 7: Send a response back to the client to inform about successful addition and the id of the created record.
            $cartid = $db->lastInsertId();
            echo 'The newly Added Cart id is: ' . $cartid;  

            add_multiple_products($json, $cartid, $db);

        } else if ($method == "PUT") {
             // STEP 3: Get the json from post body of the request
             $post = trim(file_get_contents("php://input"));
             $json = json_decode($post, true);
 
             // Step 4: Create Prepared Statement for adding a new cart record in the database.
         
             update_quantity_put($json['userid'],  $json['quantity'], $db);
             // STEP 7: Send a response back to the client to inform about successful addition and the id of the created record.
            // $cartid = $db->lastInsertId();
             $cartid = $json['cartid'];
        
             echo 'The Updated Cart id is: ' . $cartid;  
 
             delete_multiple_products($json, $cartid, $db);
             add_multiple_products($json, $cartid, $db);
        }  else if ($method == "DELETE") {
            delete_usercart_product($_GET['userid'], $_GET['cartid'], $_GET['productid'], $db);
        } else {
            print "Error: Wrong Method";
        }