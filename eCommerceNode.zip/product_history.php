<?php

        include 'dbconnect.php';

        $method = $_SERVER['REQUEST_METHOD'];

        if($method == "GET"){
            // if the GET Paramater 'id' is specified in the request, only get the specified user id.
            if(isset($_GET['userid'])){
                $sql = $db->prepare('SELECT * FROM product_hisotry WHERE userid = :userid');
	            $sql->bindValue(':userid', $_GET['userid']);
	            $sql->execute();
	            if($user = $sql->fetchAll(PDO::FETCH_ASSOC)){
                    $response = $user;
                }
	            else
                    $response = array("message"=>"User Id ". $_GET['userid']." not found");
                
                print json_encode($response);

            }


            // otherwise, get all users from the database.
            else {
                $sql = $db->prepare('SELECT * FROM product_hisotry');
	            $sql->execute();
                if($user = $sql->fetchAll(PDO::FETCH_ASSOC)){
                    $response = $user;
                }
	            else
                    $response = array("message"=>"No Product Found in Database");
                
                print json_encode($response);

            }
        }

        else if( $method == "POST"){
            
            // Get the json from post body of the request
   
            $post= trim(file_get_contents("php://input"));
            $json= json_decode($post, true);
            // Create Prepared Statement for adding a new User record in the database.
            $cmd= 'INSERT INTO product_hisotry(productid, userid, purchasedate, brand, productname) '.'VALUES(:productid, :userid, CURRENT_TIMESTAMP , :brand, :productname)';
            $sql= $db->prepare($cmd);

            // Bind the values of the post body stored in the variable $json with the database columns.
            $sql->bindValue(':productid', $json['productid']);
            $sql->bindValue(':userid', $json['userid']);
          //  $sql->bindValue(':purchasedate', $json['purchasedate']);
            $sql->bindValue(':brand', $json['brand']);
            $sql->bindValue(':productname', $json['productname']);

            // Execute the query.
            $sql->execute();

            //  Send a response back to the client to inform about successful addition and the id of the created record.
            $response= array("message"=>"New Product purchased with id ". $db->lastInsertId() . " added");
            print json_encode($response);

        }
?>