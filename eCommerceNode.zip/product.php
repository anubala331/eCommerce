<?php

    // This is the Product resource file. We will be defining RESTFul methods that will allow you to 
    // perform basic CRUD methods. 

    // STEP 1. include the database connection file.
        include 'dbconnect.php';

        $method = $_SERVER['REQUEST_METHOD'];

        if($method == "GET") {
            // if the GET Paramater 'id' is specified in the request, only get the specified product id.
            if(isset($_GET['id'])) {
                $sql = $db->prepare('SELECT * FROM product WHERE id = :id');
	            $sql->bindValue(':id', $_GET['id']);
	            $sql->execute();
	
	        if($product = $sql->fetch(PDO::FETCH_ASSOC)) {
                    $response = json_encode($product);
            }
	        else
                $response = array("message"=>"GET: Product not found");
                
                print $response;

            }// otherwise, get all products from the database.
            else {
                $sql = $db->prepare('SELECT * FROM Product');
	            $sql->execute();
                $products = $sql->fetchAll(PDO::FETCH_ASSOC);
                print (json_encode($products));

            }
        } else if( $method == "POST") {
            // STEP 3: Get the json from post body of the request
            $post = trim(file_get_contents("php://input"));
            $json = json_decode($post, true);

            // Step 4: Create Prepared Statement for adding a new User record in the database.
            $query = "INSERT INTO Product(image, pricing, shippingcost, description) VALUES(:image, :pricing, :shippingcost, :description)";
            
            $sql = $db->prepare($query);
            
            // STEP 5: Bind the values of the post body stored in the variable $json with the database columns.
            $sql->bindValue(':image', $json['image']);
            
            $sql->bindValue(':pricing', $json['pricing']);

            $sql->bindValue(':shippingcost', $json['shippingcost']);
            
            $sql->bindValue(':description', $json['description']);
            
            // STEP 6: Execute the query.
            $sql->execute();
            
            // STEP 7: Send a response back to the client to inform about successful addition and the id of the created record.
            echo 'The newly Added Product id is: ' . $db->lastInsertId();  
        } else if ($method == "PUT") {
            // Get the http body from the request
            $post = trim(file_get_contents("php://input"));
            $json = json_decode($post, true);

            // construct the prepared statement based on the id provided
            $fieldlist = "";

            if($json['image']) $fieldlist .= "image=:image,";
            if($json['pricing']) $fieldlist .= "pricing=:pricing,";
            if($json['shippingcost']) $fieldlist .= "shippingcost=:shippingcost,";
            if($json['description']) $fieldlist .= "description=:description";

            // trim any trailing ','s
            $fieldlist = trim($fieldlist, ",");
            
            // create update statement
            $cmd = "UPDATE Product SET $fieldlist WHERE id = :id";
            $sql = $db->prepare($cmd);
            
            // bind values
            if($json['image']) $sql->bindValue(':image', $json['image']);
            if($json['pricing']) $sql->bindValue(':pricing', $json['pricing']);
            if($json['shippingcost']) $sql->bindValue(':shippingcost', $json['shippingcost']);
            if($json['description']) $sql->bindValue(':description', $json['description']);
            $sql->bindValue(':id', $json['id']);

            // execute statement
            $sql->execute();
            
            // Send a response back to the client to inform about successfuly  modified records.
            $response = array("message" => "Product record modified");
            print json_encode($response);
        }  else if ($method == "DELETE") {
            // CHALLENGE: Delete the user 
            // if the GET Paramater 'id' is specified in the request, only get the specified product id.
            if(isset($_GET['id'])) {   
            // create update statement
            $sql = $db->prepare('DELETE FROM product WHERE id = :id');
	        $sql->bindValue(':id', $_GET['id']);
	        $sql->execute();
	
	       // Send a response back to the client to inform about successfuly deleted records.
            $response = array("message" => "Product Deleted Successfully");
            print json_encode($response);
            }  else {
                $response = array("message" => "DELETION: Product not found");
            }
        } else {
            $response = array("message" => "Wrong Method");
            print json_encode($response);
        }
