
# Marks: 93/100

## General Remarks
Very happy that this is one of the few groups that have given thought to how the API endpoints would serve as a backend for a complete application. While the CRUD methods provide the basic operations on the resources, from an application point of view it is important to keep in mind how the data would be retrieved by the client. 

## Proper use of VSTS/Git: 20/20%
Contributions by all group members

## Correct and complete MySQL implementation: 18/20%
1. Good job implementing the product history table to record the purchase history. This would make it easier to verify if the person who is commenting on a product has actually purchased it in the past.
2. No MySQL dump provided so it makes it hard to ensure that all necessary columns and tables have been implemented.

## Correct and complete PHP API endpoints: 25/30%
### User endpoint:
1. There is no error checking implemented: what happens if the user already exists? What happens when required fields are not filled out? 
2. There is no authentication mechanism implemented. How is a session created? Can everyone access the endpoints?

### Other endpoints
Similar issues as described above.

## Full suite of Postman tests: 30/30%
You are required to submit the exported postman collection json file like you were provided one with your lab. 

## Expectations from Asisgnment 2
From an application perspective, you will need to brainstorm the following:
1. How can you provide an endpoint to enable authentication?
2. How can you ensure that only logged in users can access an endpoint?
3. What basic sanity checks do you need to do on the backend to ensure that required fields are filled out, duplication of unique columns is avoided?
4. How can you retreive information relevant to the users? For example, the Carts REST API does not have a way to retrieve the cart of a user by user id. How will the application be able to find the cart of its logged in user? Same for comments.
